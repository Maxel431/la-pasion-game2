// Pro version script for El Viaje de la Electricidad
const LEVELS = [
  { id:'gen', title:'Central - Generación', color:'#013a5d', questions:[
    { q:'¿Qué componente gira dentro de una central hidroeléctrica para generar energía?', opts:['Motor','Turbina','Batería','Transformador'], a:1 },
    { q:'¿Qué energía convierte la turbina en electricidad?', opts:['Luminosa','Química','Mecánica','Térmica'], a:2 }
  ]},
  { id:'trans', title:'Transformador', color:'#3b2b6b', questions:[
    { q:'¿Cuál es la función principal de un transformador?', opts:['Cambiar voltaje','Almacenar energía','Producir luz','Medir corriente'], a:0 },
    { q:'¿Los transformadores suelen operar con corriente?', opts:['Alterna (AC)','Continua (DC)','Ambas','Ninguna'], a:0 }
  ]},
  { id:'red', title:'Red de Transmisión', color:'#003b2b', questions:[
    { q:'¿Por qué se usan líneas de alta tensión en transmisión?', opts:['Por estética','Para reducir pérdidas','Porque son más baratas','Para enfriar'], a:1 },
    { q:'¿Qué material es común en cables por su conductividad?', opts:['Plástico','Cobre','Madera','Vidrio'], a:1 }
  ]},
  { id:'ciudad', title:'Distribución - Ciudad', color:'#2b3b7f', questions:[
    { q:'¿Qué aparato protege contra sobrecargas en casa?', opts:['Transformador','Fusible/Interruptor','Generador','Panel solar'], a:1 },
    { q:'¿Qué es eficiente para el consumo doméstico?', opts:['Bombillas incandescentes','Bombillas LED','Dejar todo encendido','Uso excesivo'], a:1 }
  ]}
];

// DOM
const btnStart = document.getElementById('btn-start');
const btnSound = document.getElementById('btn-sound');
const btnNext = document.getElementById('btn-next');
const btnSkip = document.getElementById('btn-skip');
const btnRestart = document.getElementById('btn-restart');
const gameArea = document.getElementById('game-area');
const startScreen = document.getElementById('start-screen');
const endScreen = document.getElementById('end-screen');
const levelTitle = document.getElementById('level-title');
const levelArt = document.getElementById('level-art');
const meterFill = document.getElementById('meter-fill');
const scoreEl = document.getElementById('score');
const answersDiv = document.getElementById('answers');
const feedback = document.getElementById('feedback');
const levelsList = document.getElementById('levels-list');
const questionNumber = document.getElementById('question-number');
const questionText = document.getElementById('question-text');

let currentLevel = 0, currentQuestion = 0, score = 0, audioOn = true;

// populate levels list
LEVELS.forEach((lv, idx)=>{
  const li = document.createElement('li');
  li.textContent = lv.title;
  if(idx===0) li.classList.add('active');
  levelsList.appendChild(li);
});

function renderLevel(){
  const lv = LEVELS[currentLevel];
  levelTitle.textContent = lv.title;
  levelArt.style.background = `linear-gradient(180deg, ${lv.color}, #001)`;
  // show question
  const q = lv.questions[currentQuestion];
  questionNumber.textContent = `Nivel ${currentLevel+1} • Pregunta ${currentQuestion+1}`;
  questionText.textContent = q.q;
  answersDiv.innerHTML = '';
  q.opts.forEach((opt, i)=>{
    const b = document.createElement('button');
    b.className = 'answer-btn';
    b.textContent = `${String.fromCharCode(65+i)}. ${opt}`;
    b.addEventListener('click', ()=> selectAnswer(i, b));
    answersDiv.appendChild(b);
  });
  feedback.textContent = '';
  btnNext.style.display = 'none';
  updateMeter();
  highlightLevels();
}

function selectAnswer(i, btn){
  const lv = LEVELS[currentLevel];
  const q = lv.questions[currentQuestion];
  const correct = q.a;
  const buttons = Array.from(answersDiv.children);
  buttons.forEach(b=> b.disabled = true);
  if(i===correct){
    btn.classList.add('answer-correct');
    feedback.textContent = '¡Correcto! La energía fluye.';
    score += 1;
    playTone(900,0.12);
  } else {
    btn.classList.add('answer-wrong');
    buttons[correct].classList.add('answer-correct');
    feedback.textContent = 'Incorrecto. Pérdida parcial de energía.';
    score -= 0.5;
    playTone(260,0.18);
  }
  score = Math.max(0, score);
  scoreEl.textContent = 'Puntaje: ' + (Math.round(score*10)/10);
  btnNext.style.display = 'inline-block';
  updateMeter();
}

function updateMeter(){
  const totalQ = LEVELS.reduce((s,lv)=> s + lv.questions.length, 0);
  const answered = LEVELS.slice(0,currentLevel).reduce((s,lv)=> s + lv.questions.length, 0) + currentQuestion + 1;
  const pct = Math.round((answered/totalQ)*100);
  meterFill.style.width = pct + '%';
}

function highlightLevels(){
  const items = levelsList.children;
  for(let i=0;i<items.length;i++){
    items[i].classList.toggle('active', i===currentLevel);
  }
}

btnStart.addEventListener('click', ()=>{
  startScreen.classList.add('hidden');
  gameArea.classList.remove('hidden');
  btnStart.style.display = 'none';
  btnSound.textContent = audioOn ? '🔊' : '🔈';
  renderLevel();
  playBackground();
});

btnNext.addEventListener('click', ()=>{
  const lv = LEVELS[currentLevel];
  if(currentQuestion < lv.questions.length - 1){
    currentQuestion++;
  } else {
    if(currentLevel < LEVELS.length - 1){
      currentLevel++; currentQuestion = 0;
    } else {
      finishGame(); return;
    }
  }
  renderLevel();
});

btnSkip.addEventListener('click', ()=>{
  score -= 0.5; score = Math.max(0, score);
  scoreEl.textContent = 'Puntaje: ' + (Math.round(score*10)/10);
  btnNext.click();
});

btnRestart.addEventListener('click', ()=> location.reload());

btnSound.addEventListener('click', ()=>{
  audioOn = !audioOn;
  btnSound.textContent = audioOn ? '🔊' : '🔈';
  if(!audioOn) stopBackground();
  else playBackground();
});

function finishGame(){
  gameArea.classList.add('hidden');
  endScreen.classList.remove('hidden');
  document.getElementById('end-title').textContent = score >= (LEVELS.length*2) ? '¡Maestro de la Electricidad!' : 'Buen trabajo — sigue aprendiendo';
  document.getElementById('end-text').textContent = `Puntaje final: ${Math.round(score*10)/10}`;
  stopBackground();
  playVictory();
}

// keyboard 1-4
window.addEventListener('keydown', (e)=>{
  if(gameArea.classList.contains('hidden')) return;
  const idx = ['Digit1','Digit2','Digit3','Digit4'].indexOf(e.code);
  if(idx>=0){
    const btn = answersDiv.children[idx];
    if(btn) btn.click();
  }
});

// --- Audio: WebAudio background hum + tones
let audioCtx, bgOsc, bgGain;
function initAudio(){
  if(audioCtx) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
}
function playBackground(){
  if(!audioOn) return;
  initAudio();
  bgOsc = audioCtx.createOscillator();
  bgGain = audioCtx.createGain();
  bgOsc.type = 'sine'; bgOsc.frequency.value = 60;
  bgGain.gain.value = 0.02;
  bgOsc.connect(bgGain); bgGain.connect(audioCtx.destination);
  bgOsc.start();
}
function stopBackground(){ if(bgOsc){ bgOsc.stop(); bgOsc.disconnect(); bgOsc=null; } }

function playTone(freq, duration=0.12){
  if(!audioOn) return;
  initAudio();
  const o = audioCtx.createOscillator(); const g = audioCtx.createGain();
  o.type='sine'; o.frequency.value = freq; g.gain.value=0.08;
  o.connect(g); g.connect(audioCtx.destination);
  o.start(); setTimeout(()=> o.stop(), duration*1000);
}

function playVictory(){
  if(!audioOn) return;
  playTone(880,0.18); setTimeout(()=> playTone(1200,0.12), 200);
}

// --- Background canvas animation (particles + lightning lines)
const canvas = document.getElementById('bg-canvas');
const ctx = canvas.getContext('2d');
let W = canvas.width = innerWidth, H = canvas.height = innerHeight;
window.addEventListener('resize', ()=>{ W = canvas.width = innerWidth; H = canvas.height = innerHeight; initParticles(); });

let particles = [];
function initParticles(){ particles = []; const count = Math.max(60, Math.floor((W*H)/90000)); for(let i=0;i<count;i++){ particles.push({x:Math.random()*W,y:Math.random()*H,r:Math.random()*1.6+0.6,vx:(Math.random()-0.5)*0.6,vy:(Math.random()-0.5)*0.6,alpha:Math.random()*0.6+0.2}); } }
function draw(){ ctx.clearRect(0,0,W,H);
  // gradient bg
  const g = ctx.createLinearGradient(0,0,0,H); g.addColorStop(0,'#001021'); g.addColorStop(1,'#000610'); ctx.fillStyle = g; ctx.fillRect(0,0,W,H);
  // electric lines
  for(let i=0;i<5;i++){ ctx.beginPath(); const y = H*(0.12 + i*0.18); ctx.moveTo(0,y); for(let x=0;x<W;x+=40){ ctx.lineTo(x, y + Math.sin((x*0.02) + Date.now()*0.002 + i)*18); } ctx.strokeStyle = 'rgba(0,180,255,0.03)'; ctx.lineWidth = 1; ctx.stroke(); }
  // particles
  for(const p of particles){ p.x+=p.vx; p.y+=p.vy; if(p.x<0) p.x=W; if(p.x>W) p.x=0; if(p.y<0) p.y=H; if(p.y>H) p.y=0; ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2); ctx.fillStyle = 'rgba(60,200,255,'+p.alpha+')'; ctx.fill(); }
  requestAnimationFrame(draw);
}
initParticles(); draw();

// start with start screen visible
// show levels list titles
(function init(){
  const list = document.getElementById('levels-list');
  list.innerHTML = '';
  LEVELS.forEach(l=>{ const li = document.createElement('li'); li.textContent = l.title; list.appendChild(li); });
})();
